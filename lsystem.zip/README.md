# l-system
body and brain encoding of robots for triangle of life project
